# cau001 > 2023-03-31 10:16am
https://universe.roboflow.com/pupiup-rjvfv/cau001

Provided by a Roboflow user
License: CC BY 4.0

